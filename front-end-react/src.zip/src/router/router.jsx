import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import LoginUser from "../pages/LoginUser";
import LandingPage from "../pages/LandingPage";
import { painelRoutes } from "../painel/PainelRoutes";

function Rotas() {
    return(
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<LandingPage />}/>
                <Route path="/login" element={<LoginUser />}/>
                {/* Painel administrativo — vive sob /app, isolado da landing */}
                {painelRoutes}
            </Routes>
        </BrowserRouter>
    )
}

export default Rotas;
