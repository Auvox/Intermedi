import { NavLink } from "react-router-dom";
import { X, Zap, Plus } from "lucide-react";
import { Logo } from "../ui";
import { MENU, BASE } from "../../config/navegacao";
import { useModais } from "../../context/ModaisContext";
import "./Sidebar.css";

/** Navegação principal. Vira gaveta abaixo de 1024px. */
export function Sidebar({ aberta, aoFechar }) {
  const { abrirChamado } = useModais();

  return (
    <>
      {aberta && <div className="im-sidebar__cortina" onClick={aoFechar} />}

      <aside className={`im-sidebar ${aberta ? "im-sidebar--aberta" : ""}`}>
        <div className="im-sidebar__topo">
          <Logo escuro tamanho={28} />
          <button className="im-sidebar__fechar" onClick={aoFechar} aria-label="Fechar menu">
            <X size={18} />
          </button>
        </div>

        <nav className="im-sidebar__nav">
          {MENU.map((grupo) => (
            <div className="im-sidebar__grupo" key={grupo.grupo}>
              <p className="im-sidebar__titulo">{grupo.grupo}</p>

              {grupo.itens.map(({ caminho, rotulo, icone: Icone, selo, destaque }) => (
                <NavLink
                  key={caminho}
                  to={caminho}
                  end={caminho === BASE}
                  onClick={aoFechar}
                  className={({ isActive }) =>
                    `im-sidebar__item ${isActive ? "im-sidebar__item--ativo" : ""}`
                  }
                >
                  <Icone size={17} strokeWidth={2.2} />
                  <span className="im-sidebar__rotulo">{rotulo}</span>
                  {selo && (
                    <span className={`im-sidebar__selo ${destaque ? "im-sidebar__selo--destaque im-pulse" : ""}`}>
                      {selo}
                    </span>
                  )}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        <div className="im-sidebar__rodape">
          <div className="im-sidebar__chamariz">
            <p className="im-sidebar__chamariz-titulo">
              <Zap size={15} fill="currentColor" /> Falta ou sobra algo?
            </p>
            <p className="im-sidebar__chamariz-texto">
              Abra um chamado e a rede encontra a farmácia certa em minutos.
            </p>
            <button className="im-sidebar__chamariz-botao" onClick={abrirChamado}>
              <Plus size={15} strokeWidth={3} /> Abrir chamado
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
