const response = await fetch("http://localhost:3000/remedios", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    nomeRemedio: "Dipirona",
    descRemedio: "o melhor remedio",
    dosagemRemedio: "14x semana",
    fabricanteRemedio: "Sla"
  })
});

const json = await response.json();

console.log(json);
