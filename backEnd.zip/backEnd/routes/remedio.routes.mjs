
import {
  cadastrarRemedio,
  consultarRemedio,
  editarRemedio,
  deletarRemedio
} from "../controllers/remedio.controller.mjs";

export default function remedioRoutes(router) {

  router.post("/remedios", cadastrarRemedio);

  router.get("/remedios", consultarRemedio);

  router.get("/remedios/:id", consultarRemedio);

  router.put("/remedios/:id", editarRemedio);

  router.delete("/remedios/:id", deletarRemedio);

}